import dao.*;
import database.DatabaseConnection;
import database.DatabaseInitializer;
import exceptions.*;
import model.*;
import server.SessionManager;
import server.SessionManager.UserSession;
import service.*;
import util.PasswordUtils;

import java.io.File;
import java.sql.*;
import java.util.*;

/**
 * Comprehensive verification harness testing all library domain scenarios
 * and the 10 Core Java Authentication & Security evaluation scenarios.
 */
public class TestScenarios {

    public static void main(String[] args) {
        System.out.println("=================================================================");
        System.out.println("        LIBRABYTE - COMPREHENSIVE TEST SUITE                     ");
        System.out.println("=================================================================\n");

        try {
            // Re-initialize / ensure database schema
            DatabaseInitializer.initializeDatabase();

            BookDao bookDao = new BookDao();
            MemberDao memberDao = new MemberDao();
            IssueDao issueDao = new IssueDao();
            ReservationDao reservationDao = new ReservationDao();
            UserDao userDao = new UserDao();

            BookService bookService = new BookService(bookDao);
            MemberService memberService = new MemberService(memberDao);
            ReservationService reservationService = new ReservationService(reservationDao, bookDao, memberDao);
            LibraryService libraryService = new LibraryService(issueDao, bookDao, memberDao, bookService, reservationService);
            ReportService reportService = new ReportService(issueDao, bookDao, memberDao, reservationDao);
            AuthService authService = new AuthService(userDao, memberDao, issueDao, reservationDao);

            int passed = 0;
            int total = 29;

            // SCENARIO 1: Register a new member
            System.out.print("[TEST 1/12] Register a new member: ");
            String uniqueEmail = "devansh.test." + System.currentTimeMillis() + "@gmail.com";
            Member newMember = new Member(0, "Devansh Mittal", uniqueEmail, "+91-98119-01219", "2026-11-24", "ACTIVE");
            Member savedMember = memberService.registerMember(newMember);
            if (savedMember.getId() > 0 && "Devansh Mittal".equals(savedMember.getFullName())) {
                System.out.println("PASSED (Member ID: " + savedMember.getId() + ")");
                passed++;
            } else {
                throw new RuntimeException("Failed to register member");
            }

            // SCENARIO 2: Add a new book
            System.out.print("[TEST 2/12] Add a new book: ");
            String uniqueIsbn = "978-0" + (System.currentTimeMillis() % 1000000000L);
            Book newBook = new Book(0, uniqueIsbn, "Theory of Computation",
                    "Michael Sipser", "Discrete Mathematics", "Cengage Learning", 1, 1);
            Book savedBook = bookService.addBook(newBook);
            if (savedBook.getId() > 0 && savedBook.getAvailableCopies() == 1) {
                System.out.println("PASSED (Book ID: " + savedBook.getId() + ", Copies: " + savedBook.getAvailableCopies() + ")");
                passed++;
            } else {
                throw new RuntimeException("Failed to add book");
            }

            // SCENARIO 3: Search books by title, author, category
            System.out.print("[TEST 3/12] Search books by title, author, category: ");
            List<Book> searchTitle = bookService.searchBooks("C Programming");
            List<Book> searchAuthor = bookService.searchBooks("Tanenbaum");
            List<Book> searchCategory = bookService.searchBooks("Operating Systems");
            if (!searchTitle.isEmpty() && !searchAuthor.isEmpty() && !searchCategory.isEmpty()) {
                System.out.println("PASSED (Found by title: " + searchTitle.size() + ", author: " + searchAuthor.size() + ", category: " + searchCategory.size() + ")");
                passed++;
            } else {
                throw new RuntimeException("Search failed");
            }

            // SCENARIO 4: Issue an available book
            System.out.print("[TEST 4/12] Issue an available book: ");
            IssueRecord issue = libraryService.issueBook(savedBook.getId(), savedMember.getId());
            Book bookAfterIssue = bookService.getBookById(savedBook.getId());
            if (issue.getId() > 0 && bookAfterIssue.getAvailableCopies() == 0) {
                System.out.println("PASSED (Loan #" + issue.getId() + " created, available copies reduced to " + bookAfterIssue.getAvailableCopies() + ")");
                passed++;
            } else {
                throw new RuntimeException("Issue failed");
            }

            // SCENARIO 5: Attempt to issue a book with no available copies
            System.out.print("[TEST 5/12] Attempt to issue an unavailable book (expect BookNotAvailableException): ");
            // Register a second member
            Member member2 = memberService.registerMember(new Member(0, "Rohan Mehta", "rohan.test." + System.currentTimeMillis() + "@gmail.com", "+91-98103-45603", "2026-11-24", "ACTIVE"));
            boolean exceptionThrown = false;
            try {
                libraryService.issueBook(savedBook.getId(), member2.getId());
            } catch (BookNotAvailableException e) {
                exceptionThrown = true;
                System.out.println("PASSED (Caught expected exception: " + e.getMessage() + ")");
                passed++;
            }
            if (!exceptionThrown) throw new RuntimeException("Expected BookNotAvailableException was not thrown");

            // SCENARIO 6: Reserve an unavailable book
            System.out.print("[TEST 6/12] Reserve an unavailable book: ");
            Reservation res1 = reservationService.reserveBook(savedBook.getId(), member2.getId());
            if (res1.getId() > 0 && res1.getQueuePosition() == 1) {
                System.out.println("PASSED (Reservation #" + res1.getId() + " placed at FIFO Position #1)");
                passed++;
            } else {
                throw new RuntimeException("Failed to reserve book");
            }

            // SCENARIO 7: Add multiple members to the same reservation queue (verify FIFO ordering)
            System.out.print("[TEST 7/12] Add multiple members to same reservation queue: ");
            Member member3 = memberService.registerMember(new Member(0, "Simran Kaur", "simran.test." + System.currentTimeMillis() + "@gmail.com", "+91-98106-78906", "2026-11-24", "ACTIVE"));
            Member member4 = memberService.registerMember(new Member(0, "Arjun Kapoor", "arjun.test." + System.currentTimeMillis() + "@gmail.com", "+91-98105-67805", "2026-11-24", "ACTIVE"));
            Reservation res2 = reservationService.reserveBook(savedBook.getId(), member3.getId());
            Reservation res3 = reservationService.reserveBook(savedBook.getId(), member4.getId());

            List<Reservation> queue = reservationService.getActiveQueueForBook(savedBook.getId());
            if (queue.size() == 3 && queue.get(0).getMemberId() == member2.getId()
                    && queue.get(1).getMemberId() == member3.getId()
                    && queue.get(2).getMemberId() == member4.getId()) {
                System.out.println("PASSED (FIFO Queue has 3 members: Pos #1=" + member2.getFullName() + ", Pos #2=" + member3.getFullName() + ", Pos #3=" + member4.getFullName() + ")");
                passed++;
            } else {
                throw new RuntimeException("Queue order mismatch");
            }

            // SCENARIO 8: Return a book and verify FIFO reservation allocation!
            System.out.print("[TEST 8/12] Return book and verify FIFO reservation allocation: ");
            // When issue is returned, copy must be allocated to member2 (Pos #1) and available copies must remain 0!
            Map<String, Object> returnResult = libraryService.returnBook(issue.getId());
            boolean allocated = Boolean.TRUE.equals(returnResult.get("allocatedToQueue"));
            Book bookAfterReturn = bookService.getBookById(savedBook.getId());
            List<Reservation> remainingQueue = reservationService.getActiveQueueForBook(savedBook.getId());

            if (allocated && bookAfterReturn.getAvailableCopies() == 0 && remainingQueue.size() == 2) {
                System.out.println("PASSED (Copy allocated to " + returnResult.get("allocatedMemberName")
                        + ", public available copies remained at 0, remaining in queue: " + remainingQueue.size()
                        + ", next in line: " + remainingQueue.get(0).getMemberName() + " now at Pos #" + remainingQueue.get(0).getQueuePosition() + ")");
                passed++;
            } else {
                throw new RuntimeException("FIFO Return allocation failed: allocated=" + allocated + ", copies=" + bookAfterReturn.getAvailableCopies());
            }

            // SCENARIO 9: Cancel a reservation
            System.out.print("[TEST 9/12] Cancel a reservation and verify queue recomputation: ");
            // member3 is at pos #1 now, member4 is at pos #2. Cancel member3:
            boolean cancelled = reservationService.cancelReservation(res2.getId());
            List<Reservation> queueAfterCancel = reservationService.getActiveQueueForBook(savedBook.getId());
            if (cancelled && queueAfterCancel.size() == 1 && queueAfterCancel.get(0).getMemberId() == member4.getId() && queueAfterCancel.get(0).getQueuePosition() == 1) {
                System.out.println("PASSED (Reservation cancelled. " + member4.getFullName() + " promoted from Pos #2 to Pos #1)");
                passed++;
            } else {
                throw new RuntimeException("Cancel reservation failed");
            }

            // SCENARIO 10: Generate overdue reports with Comparator sorting
            System.out.print("[TEST 10/12] Generate overdue report (sorted by overdue days via Comparator): ");
            List<OverdueReportItem> overdues = reportService.getOverdueReport();
            boolean isSorted = true;
            for (int i = 0; i < overdues.size() - 1; i++) {
                if (overdues.get(i).getOverdueDays() < overdues.get(i + 1).getOverdueDays()) {
                    isSorted = false;
                    break;
                }
            }
            if (!overdues.isEmpty() && isSorted) {
                System.out.println("PASSED (Found " + overdues.size() + " overdue records, correctly sorted descending: "
                        + overdues.get(0).getOverdueDays() + " days >= " + overdues.get(overdues.size() - 1).getOverdueDays() + " days)");
                passed++;
            } else {
                throw new RuntimeException("Overdue report sorting failed");
            }

            // SCENARIO 11: Generate frequently borrowed book reports with Comparator sorting
            System.out.print("[TEST 11/12] Generate popular books report (sorted by borrow count via Comparator): ");
            List<PopularBookReportItem> popular = reportService.getPopularBooksReport();
            boolean popSorted = true;
            for (int i = 0; i < popular.size() - 1; i++) {
                if (popular.get(i).getBorrowCount() < popular.get(i + 1).getBorrowCount()) {
                    popSorted = false;
                    break;
                }
            }
            if (!popular.isEmpty() && popSorted) {
                System.out.println("PASSED (Top book: \"" + popular.get(0).getTitle() + "\" with "
                        + popular.get(0).getBorrowCount() + " borrows, Rank #" + popular.get(0).getPopularityRank() + ")");
                passed++;
            } else {
                throw new RuntimeException("Popular books sorting failed");
            }

            // SCENARIO 12: Restart simulation and verify database persistence
            System.out.print("[TEST 12/22] Restart application simulation & verify SQLite persistence: ");
            // Simulate complete application restart by creating brand new Service instances
            ReservationService newReservationService = new ReservationService(reservationDao, bookDao, memberDao);
            List<Reservation> persistedQueue = newReservationService.getActiveQueueForBook(savedBook.getId());
            if (persistedQueue.size() == 1 && persistedQueue.get(0).getMemberId() == member4.getId() && persistedQueue.get(0).getQueuePosition() == 1) {
                System.out.println("PASSED (Queue state completely restored from SQLite after restart! Next patron: "
                        + persistedQueue.get(0).getMemberName() + " at Pos #1)");
                passed++;
            } else {
                throw new RuntimeException("Persistence verification failed");
            }

            // =================================================================
            // AUTHENTICATION, RBAC & SECURITY VERIFICATION (TESTS 13 - 22)
            // =================================================================
            System.out.println("\n--- Core Java Authentication & Security Suite ---");

            // TEST 13: New User Registration
            System.out.print("[TEST 13/22] New user registration with PBKDF2 hashing: ");
            String testEmail = "jasleen.test." + System.currentTimeMillis() + "@gmail.com";
            User regUser = authService.register("Jasleen Kaur", testEmail, "+91-98118-90118", "Student@123", "Student@123", "MEMBER");
            if (regUser.getId() > 0 && regUser.getMemberId() != null && "MEMBER".equals(regUser.getRole())) {
                System.out.println("PASSED (User ID #" + regUser.getId() + ", Linked Member ID #" + regUser.getMemberId() + ")");
                passed++;
            } else {
                throw new RuntimeException("Registration failed: user ID or linked member ID missing");
            }

            // TEST 14: Duplicate Email Rejection
            System.out.print("[TEST 14/22] Duplicate email registration rejection: ");
            boolean dupCaught = false;
            try {
                authService.register("Jasleen Duplicate", testEmail, "+91-98118-90118", "Student@123", "Student@123", "MEMBER");
            } catch (LibraryException e) {
                if (e.getStatusCode() == 409) {
                    dupCaught = true;
                    System.out.println("PASSED (Caught expected 409 Conflict: " + e.getMessage() + ")");
                    passed++;
                }
            }
            if (!dupCaught) throw new RuntimeException("Duplicate email was not rejected with 409 Conflict");

            // TEST 15: Successful User Login & Session Establishment
            System.out.print("[TEST 15/22] Successful credential verification & session creation: ");
            User dbUser = userDao.findByEmail(testEmail);
            boolean verified = PasswordUtils.verifyPassword("Student@123", dbUser.getSalt(), dbUser.getPasswordHash());
            UserSession userSession = SessionManager.createSession(dbUser, false);
            if (verified && userSession != null && userSession.getSessionId().length() >= 32) {
                System.out.println("PASSED (Session token issued: " + userSession.getSessionId().substring(0, 12) + "...)");
                passed++;
            } else {
                throw new RuntimeException("Login or session creation failed");
            }

            // TEST 16: Incorrect Password Rejection
            System.out.print("[TEST 16/22] Incorrect password rejection: ");
            boolean wrongMatches = PasswordUtils.verifyPassword("WrongPassword123!", dbUser.getSalt(), dbUser.getPasswordHash());
            if (!wrongMatches) {
                System.out.println("PASSED (Invalid password rejected by PBKDF2 comparison)");
                passed++;
            } else {
                throw new RuntimeException("Incorrect password was falsely accepted");
            }

            // TEST 17: Password Hashing & Salt Verification (Never plain text)
            System.out.print("[TEST 17/22] Cryptographic password hash & random salt verification: ");
            boolean notPlainText = !dbUser.getPasswordHash().contains("Student@123");
            byte[] decodedHash = java.util.Base64.getDecoder().decode(dbUser.getPasswordHash());
            byte[] decodedSalt = java.util.Base64.getDecoder().decode(dbUser.getSalt());
            boolean hashLengthValid = decodedHash.length == 32; // 256 bits key length
            boolean saltLengthValid = decodedSalt.length == 16;  // 16 bytes random salt
            if (notPlainText && hashLengthValid && saltLengthValid) {
                System.out.println("PASSED (PBKDF2WithHmacSHA256, 65,536 iterations, 256-bit hash, 16-byte random salt)");
                passed++;
            } else {
                throw new RuntimeException("Password hash or salt validation failed: hashBytes=" + decodedHash.length + ", saltBytes=" + decodedSalt.length);
            }

            // TEST 18: Session Persistence & Retrieval
            System.out.print("[TEST 18/22] Server-side session retrieval & active state: ");
            UserSession retrievedSession = SessionManager.getSession(userSession.getSessionId());
            if (retrievedSession != null && retrievedSession.getUserId() == dbUser.getId() && !retrievedSession.isExpired()) {
                System.out.println("PASSED (Session active for user " + retrievedSession.getFullName() + ")");
                passed++;
            } else {
                throw new RuntimeException("Session persistence retrieval failed");
            }

            // TEST 19: Session Logout & Invalidation
            System.out.print("[TEST 19/22] Logout session invalidation: ");
            SessionManager.invalidateSession(userSession.getSessionId());
            UserSession invalidatedSession = SessionManager.getSession(userSession.getSessionId());
            if (invalidatedSession == null) {
                System.out.println("PASSED (Session token successfully purged from active sessions)");
                passed++;
            } else {
                throw new RuntimeException("Session was not invalidated upon logout");
            }

            // TEST 20: Unauthorized Dashboard Access Rejection
            System.out.print("[TEST 20/22] Unauthorized access protection: ");
            UserSession fakeSession = SessionManager.getSession("tampered-invalid-session-id");
            if (fakeSession == null) {
                System.out.println("PASSED (Unrecognized tokens rejected with null session)");
                passed++;
            } else {
                throw new RuntimeException("Invalid session token was accepted");
            }

            // TEST 21: Role-Based Access Control (RBAC: Admin vs Member)
            System.out.print("[TEST 21/22] Role-Based Access Control (ADMIN vs MEMBER): ");
            User adminUser = userDao.findByEmail("admin@librabyte.com");
            UserSession adminSession = SessionManager.createSession(adminUser, false);
            UserSession memberSession = SessionManager.createSession(dbUser, false);

            boolean adminCheck = adminSession.isAdmin();
            boolean memberCheck = memberSession.isAdmin();

            if (adminCheck && !memberCheck) {
                System.out.println("PASSED (ADMIN correctly authorized, MEMBER role forbidden from admin operations)");
                passed++;
            } else {
                throw new RuntimeException("Role check failed: admin=" + adminCheck + ", memberAsAdmin=" + memberCheck);
            }

            // TEST 22: Session Expiry Handling
            System.out.print("[TEST 22/22] Session expiration enforcement: ");
            UserSession expiredSession = new UserSession(
                    "expired-test-token",
                    dbUser.getId(),
                    dbUser.getEmail(),
                    dbUser.getFullName(),
                    "MEMBER",
                    dbUser.getMemberId(),
                    false,
                    -10 // Expired 10 seconds ago
            );
            boolean isExpired = expiredSession.isExpired();
            if (isExpired) {
                System.out.println("PASSED (Expired sessions correctly identified and discarded)");
                passed++;
            } else {
                throw new RuntimeException("Expired session was marked active");
            }

            // TEST 23: Retrieve Profile Information (Both Admin and Member)
            System.out.print("[TEST 23/29] Retrieve personal profile for Admin & Member: ");
            Map<String, Object> adminProfile = authService.getProfile(adminUser.getId());
            Map<String, Object> memberProfile = authService.getProfile(dbUser.getId());
            if ("ADMIN".equals(adminProfile.get("role")) && "MEMBER".equals(memberProfile.get("role"))
                    && memberProfile.containsKey("activeLoans")
                    && memberProfile.containsKey("activeReservations")
                    && memberProfile.containsKey("borrowingHistory")) {
                System.out.println("PASSED (Admin & Member profile retrieved with full metadata & activity lists)");
                passed++;
            } else {
                throw new RuntimeException("Profile structure verification failed: " + memberProfile);
            }

            // TEST 24: Update Personal Profile Details (Name, Phone, Avatar)
            System.out.print("[TEST 24/29] Update personal profile details: ");
            String updatedName = "Devansh Sharma Updated";
            String updatedPhone = "+91-98111-22334";
            String avatarData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
            Map<String, Object> updatedProfile = authService.updateProfile(
                    dbUser.getId(),
                    updatedName,
                    dbUser.getEmail(),
                    updatedPhone,
                    avatarData,
                    memberSession.getSessionId()
            );
            if (updatedName.equals(updatedProfile.get("fullName"))
                    && updatedPhone.equals(updatedProfile.get("phone"))
                    && avatarData.equals(updatedProfile.get("profileImage"))) {
                System.out.println("PASSED (Profile updated & persisted via JDBC)");
                passed++;
            } else {
                throw new RuntimeException("Profile update verification failed: " + updatedProfile);
            }

            // TEST 25: Synchronize linked patron table in database
            System.out.print("[TEST 25/29] Synchronize linked patron member record: ");
            Member linkedMember = memberDao.findById(dbUser.getMemberId());
            if (linkedMember != null && updatedName.equals(linkedMember.getFullName()) && updatedPhone.equals(linkedMember.getPhone())) {
                System.out.println("PASSED (Patron record synchronized with updated personal details)");
                passed++;
            } else {
                throw new RuntimeException("Patron sync failed: " + linkedMember);
            }

            // TEST 26: Duplicate Email Prevention on Profile Update
            System.out.print("[TEST 26/29] Duplicate email prevention on profile update: ");
            boolean duplicateBlocked = false;
            try {
                authService.updateProfile(dbUser.getId(), "Test User", "admin@librabyte.com", "+91-98765-43210", "", null);
            } catch (LibraryException e) {
                if (e.getStatusCode() == 409) {
                    duplicateBlocked = true;
                }
            }
            if (duplicateBlocked) {
                System.out.println("PASSED (409 Conflict correctly thrown for existing email)");
                passed++;
            } else {
                throw new RuntimeException("Duplicate email was not rejected");
            }

            // TEST 27: Validate Indian Mobile Number Format
            System.out.print("[TEST 27/29] Indian mobile number validation: ");
            boolean invalidPhoneBlocked = false;
            try {
                authService.updateProfile(dbUser.getId(), updatedName, dbUser.getEmail(), "12345", "", null);
            } catch (LibraryException e) {
                if (e.getStatusCode() == 400) {
                    invalidPhoneBlocked = true;
                }
            }
            if (invalidPhoneBlocked) {
                System.out.println("PASSED (400 Bad Request correctly thrown for invalid phone)");
                passed++;
            } else {
                throw new RuntimeException("Invalid phone number was accepted");
            }

            // TEST 28: Secure PBKDF2 Password Change Workflow
            System.out.print("[TEST 28/29] PBKDF2 Password change workflow: ");
            boolean wrongOldRejected = false;
            try {
                authService.changePassword(dbUser.getId(), "WrongOldPass!123", "BrandNewPass@456", "BrandNewPass@456");
            } catch (LibraryException e) {
                wrongOldRejected = true;
            }
            authService.changePassword(dbUser.getId(), "Student@123", "BrandNewPass@456", "BrandNewPass@456");
            User userAfterChange = userDao.findById(dbUser.getId());
            boolean newPassVerified = PasswordUtils.verifyPassword("BrandNewPass@456", userAfterChange.getSalt(), userAfterChange.getPasswordHash());
            boolean oldPassFails = !PasswordUtils.verifyPassword("Student@123", userAfterChange.getSalt(), userAfterChange.getPasswordHash());
            if (wrongOldRejected && newPassVerified && oldPassFails) {
                System.out.println("PASSED (Old password verified, new PBKDF2 hash stored, old password invalidated)");
                passed++;
            } else {
                throw new RuntimeException("Password change failed to authenticate with new credentials");
            }

            // TEST 29: Role Tampering Prevention
            System.out.print("[TEST 29/29] Prevent role privilege escalation: ");
            User reloadedUser = userDao.findById(dbUser.getId());
            if ("MEMBER".equals(reloadedUser.getRole())) {
                System.out.println("PASSED (User role remained strictly MEMBER; cannot be modified by user)");
                passed++;
            } else {
                throw new RuntimeException("Role was tampered: " + reloadedUser.getRole());
            }

            // Clean up temporary test data created during test execution
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement cleanup = conn.createStatement()) {
                cleanup.executeUpdate("DELETE FROM reservations WHERE book_id IN (SELECT id FROM books WHERE title = 'Theory of Computation')");
                cleanup.executeUpdate("DELETE FROM issue_records WHERE book_id IN (SELECT id FROM books WHERE title = 'Theory of Computation')");
                cleanup.executeUpdate("DELETE FROM books WHERE title = 'Theory of Computation'");
                cleanup.executeUpdate("DELETE FROM users WHERE email LIKE '%.test.%'");
                cleanup.executeUpdate("DELETE FROM reservations WHERE member_id IN (SELECT id FROM members WHERE email LIKE '%.test.%')");
                cleanup.executeUpdate("DELETE FROM issue_records WHERE member_id IN (SELECT id FROM members WHERE email LIKE '%.test.%')");
                cleanup.executeUpdate("DELETE FROM members WHERE email LIKE '%.test.%'");
            } catch (Exception ignored) {}

            System.out.println("\n=================================================================");
            System.out.println("   ALL " + passed + "/" + total + " TEST SCENARIOS PASSED WITH 100% SUCCESS!   ");
            System.out.println("=================================================================");

        } catch (Exception e) {
            System.err.println("\nTEST FAILED WITH EXCEPTION: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
