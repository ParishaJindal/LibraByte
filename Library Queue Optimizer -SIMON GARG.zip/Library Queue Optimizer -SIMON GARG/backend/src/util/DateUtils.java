package util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateUtils {
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static String today() {
        return LocalDate.now().format(DATE_FORMATTER);
    }

    public static String now() {
        return LocalDateTime.now().format(DATE_TIME_FORMATTER);
    }

    public static String addDays(String dateStr, int days) {
        LocalDate date = LocalDate.parse(dateStr, DATE_FORMATTER);
        return date.plusDays(days).format(DATE_FORMATTER);
    }

    public static long daysBetween(String startStr, String endStr) {
        LocalDate start = LocalDate.parse(startStr.substring(0, 10), DATE_FORMATTER);
        LocalDate end = LocalDate.parse(endStr.substring(0, 10), DATE_FORMATTER);
        return ChronoUnit.DAYS.between(start, end);
    }

    public static long calculateOverdueDays(String dueDateStr) {
        if (dueDateStr == null || dueDateStr.isEmpty()) return 0;
        try {
            LocalDate due = LocalDate.parse(dueDateStr.substring(0, 10), DATE_FORMATTER);
            LocalDate today = LocalDate.now();
            if (today.isAfter(due)) {
                return ChronoUnit.DAYS.between(due, today);
            }
        } catch (Exception e) {
            // fallback
        }
        return 0;
    }
}
