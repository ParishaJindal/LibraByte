package util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

/**
 * Enterprise Password Security Utility.
 * Implements salted PBKDF2WithHmacSHA256 hashing using Core Java cryptography.
 * Never stores plain text passwords.
 */
public class PasswordUtils {
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 65536;
    private static final int KEY_LENGTH = 256; // 32 bytes
    private static final int SALT_LENGTH = 16;  // 16 bytes
    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * Generates a cryptographically secure random 16-byte salt, Base64-encoded.
     */
    public static String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Computes the PBKDF2WithHmacSHA256 hash of a password using the given salt.
     */
    public static String hashPassword(String password, String saltBase64) {
        if (password == null || saltBase64 == null) {
            throw new IllegalArgumentException("Password and salt cannot be null");
        }
        try {
            byte[] salt = Base64.getDecoder().decode(saltBase64);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error hashing password with PBKDF2: " + e.getMessage(), e);
        }
    }

    /**
     * Constant-time password verification to prevent timing attack vulnerabilities.
     */
    public static boolean verifyPassword(String candidatePassword, String saltBase64, String expectedHashBase64) {
        if (candidatePassword == null || saltBase64 == null || expectedHashBase64 == null) {
            return false;
        }
        try {
            String candidateHash = hashPassword(candidatePassword, saltBase64);
            byte[] expected = Base64.getDecoder().decode(expectedHashBase64);
            byte[] actual = Base64.getDecoder().decode(candidateHash);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }
}
