package service;

import dao.MemberDao;
import exceptions.LibraryException;
import exceptions.MemberNotFoundException;
import model.Member;
import util.DateUtils;

import java.sql.SQLException;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Service managing library members with runtime HashMap caching.
 */
public class MemberService {
    private final MemberDao memberDao;
    // Runtime HashMap for fast member lookup
    private final Map<Integer, Member> memberMap;

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");

    public MemberService(MemberDao memberDao) {
        this.memberDao = memberDao;
        this.memberMap = new HashMap<>();
        syncCache();
    }

    public synchronized void syncCache() {
        memberMap.clear();
        try {
            List<Member> members = memberDao.findAll();
            for (Member m : members) {
                memberMap.put(m.getId(), m);
            }
        } catch (SQLException e) {
            System.err.println("Failed to cache members: " + e.getMessage());
        }
    }

    public synchronized List<Member> getAllMembers() throws SQLException {
        List<Member> members = memberDao.findAll();
        memberMap.clear();
        for (Member m : members) {
            memberMap.put(m.getId(), m);
        }
        return members;
    }

    public synchronized Member getMemberById(int id) throws LibraryException {
        if (memberMap.containsKey(id)) {
            return memberMap.get(id);
        }
        try {
            Member member = memberDao.findById(id);
            if (member == null) {
                throw new MemberNotFoundException(id);
            }
            memberMap.put(id, member);
            return member;
        } catch (SQLException e) {
            throw new LibraryException("Database error: " + e.getMessage(), 500);
        }
    }

    public List<Member> searchMembers(String query) throws SQLException {
        if (query == null || query.trim().isEmpty()) {
            return getAllMembers();
        }
        return memberDao.search(query.trim());
    }

    public synchronized Member registerMember(Member member) throws LibraryException {
        validateMember(member);
        try {
            Member existing = memberDao.findByEmail(member.getEmail());
            if (existing != null) {
                throw new LibraryException("A member with email '" + member.getEmail() + "' already exists.", 409);
            }

            if (member.getRegistrationDate() == null || member.getRegistrationDate().isEmpty()) {
                member.setRegistrationDate(DateUtils.today());
            }
            member.setCreatedAt(DateUtils.now());
            if (member.getStatus() == null || member.getStatus().isEmpty()) {
                member.setStatus("ACTIVE");
            }

            int id = memberDao.insert(member);
            member.setId(id);
            memberMap.put(id, member);
            return member;
        } catch (SQLException e) {
            throw new LibraryException("Database error registering member: " + e.getMessage(), 500);
        }
    }

    public synchronized Member updateMember(Member member) throws LibraryException {
        validateMember(member);
        try {
            Member existing = memberDao.findById(member.getId());
            if (existing == null) {
                throw new MemberNotFoundException(member.getId());
            }

            Member emailCheck = memberDao.findByEmail(member.getEmail());
            if (emailCheck != null && emailCheck.getId() != member.getId()) {
                throw new LibraryException("Another member is already using email: " + member.getEmail(), 409);
            }

            boolean success = memberDao.update(member);
            if (!success) {
                throw new LibraryException("Failed to update member.", 500);
            }

            memberMap.put(member.getId(), member);
            return member;
        } catch (SQLException e) {
            throw new LibraryException("Database error updating member: " + e.getMessage(), 500);
        }
    }

    public synchronized boolean deleteMember(int id) throws LibraryException {
        try {
            Member member = memberDao.findById(id);
            if (member == null) {
                throw new MemberNotFoundException(id);
            }

            if (memberDao.hasActiveIssuesOrReservations(id)) {
                throw new LibraryException("Cannot delete member '" + member.getFullName() + "' because they have active book issues or reservations.", 400);
            }

            boolean deleted = memberDao.delete(id);
            if (deleted) {
                memberMap.remove(id);
            }
            return deleted;
        } catch (SQLException e) {
            throw new LibraryException("Database error deleting member: " + e.getMessage(), 500);
        }
    }

    private void validateMember(Member member) throws LibraryException {
        if (member.getFullName() == null || member.getFullName().trim().isEmpty()) {
            throw new LibraryException("Member full name is required.", 400);
        }
        if (member.getEmail() == null || !EMAIL_PATTERN.matcher(member.getEmail().trim()).matches()) {
            throw new LibraryException("Please provide a valid email address.", 400);
        }
        if (member.getPhone() == null || member.getPhone().trim().length() < 7) {
            throw new LibraryException("Please provide a valid phone number.", 400);
        }
    }
}
