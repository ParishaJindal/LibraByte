package service;

import dao.BookDao;
import dao.MemberDao;
import dao.ReservationDao;
import database.DatabaseConnection;
import exceptions.BookNotFoundException;
import exceptions.DuplicateReservationException;
import exceptions.LibraryException;
import exceptions.MemberNotFoundException;
import model.Book;
import model.Member;
import model.Reservation;
import util.DateUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/**
 * Reservation Queue Manager.
 * Implements FIFO (First In, First Out) queue using Java Queue and LinkedList.
 * Maintains runtime mappings using HashMap<Integer, Queue<Reservation>>.
 * Automatically synchronizes with SQLite database for crash persistence.
 */
public class ReservationService {
    private final ReservationDao reservationDao;
    private final BookDao bookDao;
    private final MemberDao memberDao;

    // Runtime HashMap mapping bookId to its dedicated FIFO Queue of Reservations
    private final Map<Integer, Queue<Reservation>> bookReservationQueues;

    public ReservationService(ReservationDao reservationDao, BookDao bookDao, MemberDao memberDao) {
        this.reservationDao = reservationDao;
        this.bookDao = bookDao;
        this.memberDao = memberDao;
        this.bookReservationQueues = new HashMap<>();
        syncQueuesFromDatabase();
    }

    /**
     * Initializes/reloads all active FIFO reservation queues from database.
     * Guarantees queue persistence across server restarts.
     */
    public synchronized void syncQueuesFromDatabase() {
        bookReservationQueues.clear();
        try {
            List<Book> books = bookDao.findAll();
            for (Book book : books) {
                List<Reservation> activeReservations = reservationDao.findActiveByBookId(book.getId());
                // Sort by queue_position ascending (FIFO)
                activeReservations.sort(Comparator.comparingInt(Reservation::getQueuePosition)
                        .thenComparing(Reservation::getReservationDate));

                Queue<Reservation> queue = new LinkedList<>(activeReservations);
                bookReservationQueues.put(book.getId(), queue);
            }
            System.out.println("Loaded reservation queues for " + bookReservationQueues.size() + " books.");
        } catch (SQLException e) {
            System.err.println("Failed to sync reservation queues: " + e.getMessage());
        }
    }

    /**
     * Adds a member to the FIFO reservation queue for a book.
     */
    public synchronized Reservation reserveBook(int bookId, int memberId) throws LibraryException {
        try {
            Book book = bookDao.findById(bookId);
            if (book == null) {
                throw new BookNotFoundException(bookId);
            }

            Member member = memberDao.findById(memberId);
            if (member == null) {
                throw new MemberNotFoundException(memberId);
            }

            if (!"ACTIVE".equalsIgnoreCase(member.getStatus())) {
                throw new LibraryException("Member is not in ACTIVE status (" + member.getStatus() + "). Cannot reserve books.", 403);
            }

            // Prevent duplicate active reservations
            if (reservationDao.hasActiveReservation(memberId, bookId)) {
                throw new DuplicateReservationException(memberId, bookId);
            }

            Queue<Reservation> queue = bookReservationQueues.computeIfAbsent(bookId, k -> new LinkedList<>());
            int newPosition = queue.size() + 1;
            String now = DateUtils.now();

            Reservation reservation = new Reservation(0, bookId, memberId, now, newPosition, "WAITING");
            reservation.setCreatedAt(now);
            reservation.setBookTitle(book.getTitle());
            reservation.setBookAuthor(book.getAuthor());
            reservation.setMemberName(member.getFullName());
            reservation.setMemberEmail(member.getEmail());

            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    int genId = reservationDao.insert(conn, reservation);
                    reservation.setId(genId);
                    conn.commit();
                } catch (SQLException ex) {
                    conn.rollback();
                    throw new LibraryException("Database error saving reservation: " + ex.getMessage(), 500);
                }
            }

            // Add to in-memory FIFO queue
            queue.offer(reservation);

            return reservation;
        } catch (SQLException e) {
            throw new LibraryException("Database error: " + e.getMessage(), 500);
        }
    }

    /**
     * Checks if a book has any pending reservations in its FIFO queue.
     */
    public synchronized boolean hasActiveReservations(int bookId) {
        Queue<Reservation> queue = bookReservationQueues.get(bookId);
        return queue != null && !queue.isEmpty();
    }

    /**
     * Peeks at the next member in the FIFO queue without removing them.
     */
    public synchronized Reservation peekNextInQueue(int bookId) {
        Queue<Reservation> queue = bookReservationQueues.get(bookId);
        return queue != null ? queue.peek() : null;
    }

    /**
     * Polls the next member in the FIFO queue and allocates the book to them.
     * Updates database transactionally and adjusts remaining positions.
     */
    public synchronized Reservation pollAndAllocateNext(Connection conn, int bookId) throws SQLException {
        Queue<Reservation> queue = bookReservationQueues.get(bookId);
        if (queue == null || queue.isEmpty()) {
            return null;
        }

        // FIFO removal
        Reservation allocated = queue.poll();
        if (allocated != null) {
            reservationDao.updateStatus(conn, allocated.getId(), "ALLOCATED");
            allocated.setStatus("ALLOCATED");

            // Recompute remaining positions in DB and update in-memory objects
            reservationDao.recomputeQueuePositions(conn, bookId);
            int pos = 1;
            for (Reservation r : queue) {
                r.setQueuePosition(pos++);
            }
        }
        return allocated;
    }

    /**
     * Cancels an active reservation and shifts remaining positions forward.
     */
    public synchronized boolean cancelReservation(int reservationId) throws LibraryException {
        try {
            Reservation reservation = reservationDao.findById(reservationId);
            if (reservation == null) {
                throw new LibraryException("Reservation with ID " + reservationId + " not found.", 404);
            }
            if (!"WAITING".equalsIgnoreCase(reservation.getStatus())) {
                throw new LibraryException("Cannot cancel reservation with status: " + reservation.getStatus(), 400);
            }

            int bookId = reservation.getBookId();
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    reservationDao.updateStatus(conn, reservationId, "CANCELLED");
                    reservationDao.recomputeQueuePositions(conn, bookId);
                    conn.commit();
                } catch (SQLException ex) {
                    conn.rollback();
                    throw new LibraryException("Failed to cancel reservation in database: " + ex.getMessage(), 500);
                }
            }

            // Update in-memory queue
            Queue<Reservation> queue = bookReservationQueues.get(bookId);
            if (queue != null) {
                queue.removeIf(r -> r.getId() == reservationId);
                int pos = 1;
                for (Reservation r : queue) {
                    r.setQueuePosition(pos++);
                }
            }

            return true;
        } catch (SQLException e) {
            throw new LibraryException("Database error: " + e.getMessage(), 500);
        }
    }

    public synchronized List<Reservation> getActiveQueueForBook(int bookId) {
        Queue<Reservation> queue = bookReservationQueues.get(bookId);
        if (queue == null) return Collections.emptyList();
        return new ArrayList<>(queue);
    }

    public synchronized List<Reservation> getAllReservations() throws SQLException {
        return reservationDao.findAll();
    }

    public synchronized int getQueueSize(int bookId) {
        Queue<Reservation> queue = bookReservationQueues.get(bookId);
        return queue != null ? queue.size() : 0;
    }

    public synchronized int getTotalActiveReservations() throws SQLException {
        return reservationDao.countActiveReservations();
    }

    public synchronized List<Reservation> getReservationsByMemberId(int memberId) throws SQLException {
        return reservationDao.findByMemberId(memberId);
    }
}
