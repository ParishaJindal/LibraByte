package service;

import dao.BookDao;
import dao.IssueDao;
import dao.MemberDao;
import database.DatabaseConnection;
import exceptions.BookNotAvailableException;
import exceptions.BookNotFoundException;
import exceptions.InvalidReturnException;
import exceptions.LibraryException;
import exceptions.MemberNotFoundException;
import model.Book;
import model.IssueRecord;
import model.Member;
import model.Reservation;
import util.DateUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/**
 * Core Library Service orchestrating Book Issuing, Returning, and FIFO Queue Allocation.
 * Implements strict JDBC Transaction Management (setAutoCommit(false), commit(), rollback()).
 */
public class LibraryService {
    private final IssueDao issueDao;
    private final BookDao bookDao;
    private final MemberDao memberDao;
    private final BookService bookService;
    private final ReservationService reservationService;

    public LibraryService(IssueDao issueDao, BookDao bookDao, MemberDao memberDao,
                          BookService bookService, ReservationService reservationService) {
        this.issueDao = issueDao;
        this.bookDao = bookDao;
        this.memberDao = memberDao;
        this.bookService = bookService;
        this.reservationService = reservationService;
    }

    /**
     * Issues an available book copy to a member using a JDBC transaction.
     * Decrements available copy count and creates an IssueRecord.
     */
    public synchronized IssueRecord issueBook(int bookId, int memberId) throws LibraryException {
        try {
            Book book = bookDao.findById(bookId);
            if (book == null) {
                throw new BookNotFoundException(bookId);
            }

            Member member = memberDao.findById(memberId);
            if (member == null) {
                throw new MemberNotFoundException(memberId);
            }

            if (!"ACTIVE".equalsIgnoreCase(member.getStatus())) {
                throw new LibraryException("Member status is '" + member.getStatus() + "'. Only ACTIVE members can borrow books.", 403);
            }

            // Check if copies are available
            if (book.getAvailableCopies() <= 0) {
                throw new BookNotAvailableException(bookId);
            }

            String today = DateUtils.today();
            String dueDate = DateUtils.addDays(today, 14); // 14-day loan period
            String now = DateUtils.now();

            IssueRecord issue = new IssueRecord(0, bookId, memberId, today, dueDate, null, "ISSUED");
            issue.setCreatedAt(now);
            issue.setBookTitle(book.getTitle());
            issue.setBookIsbn(book.getIsbn());
            issue.setMemberName(member.getFullName());
            issue.setMemberEmail(member.getEmail());

            // JDBC Transaction
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    // 1. Decrement available copies
                    boolean updated = bookDao.updateAvailableCopies(conn, bookId, -1);
                    if (!updated) {
                        conn.rollback();
                        throw new BookNotAvailableException("Failed to reserve copy: no copies available.");
                    }

                    // 2. Insert issue record
                    int issueId = issueDao.insert(conn, issue);
                    issue.setId(issueId);

                    // If this member had an active reservation or allocation for this book, mark it fulfilled
                    List<Reservation> activeReservations = reservationService.getActiveQueueForBook(bookId);
                    for (Reservation r : activeReservations) {
                        if (r.getMemberId() == memberId) {
                            reservationService.cancelReservation(r.getId());
                            break;
                        }
                    }

                    conn.commit();
                } catch (Exception ex) {
                    conn.rollback();
                    if (ex instanceof LibraryException) throw (LibraryException) ex;
                    throw new LibraryException("Transaction failed while issuing book: " + ex.getMessage(), 500);
                }
            }

            // Update in-memory caches
            bookService.syncCache();
            return issue;

        } catch (SQLException e) {
            throw new LibraryException("Database error: " + e.getMessage(), 500);
        }
    }

    /**
     * Returns an issued book.
     * CRITICAL FIFO QUEUE LOGIC:
     * If pending reservations exist in the queue:
     * - Dequeue the first member (FIFO order).
     * - Allocate the returned copy to that member.
     * - Do NOT increase public available copies (it is held for the reserved member).
     * If no reservation exists:
     * - Increase available copies by 1.
     */
    public synchronized Map<String, Object> returnBook(int issueId) throws LibraryException {
        try {
            IssueRecord issue = issueDao.findById(issueId);
            if (issue == null) {
                throw new InvalidReturnException("Issue record with ID " + issueId + " not found.");
            }

            if ("RETURNED".equalsIgnoreCase(issue.getStatus())) {
                throw new InvalidReturnException("Book has already been returned on " + issue.getReturnDate());
            }

            int bookId = issue.getBookId();
            String today = DateUtils.today();
            long overdueDays = DateUtils.calculateOverdueDays(issue.getDueDate());
            boolean isOverdue = overdueDays > 0;

            Reservation allocatedReservation = null;

            // JDBC Transaction for atomic return and queue handoff
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    // 1. Mark issue record as RETURNED
                    issueDao.updateReturn(conn, issueId, today, "RETURNED");

                    // 2. Check FIFO reservation queue
                    if (reservationService.hasActiveReservations(bookId)) {
                        // Dequeue first member in queue and assign copy
                        allocatedReservation = reservationService.pollAndAllocateNext(conn, bookId);
                        // Notice: Available copies count is NOT incremented, preserving the copy for the reserved member!
                        System.out.println("FIFO Queue Allocation: Returned copy of book ID " + bookId +
                                " allocated to reserved member ID " + allocatedReservation.getMemberId());
                    } else {
                        // No waitlist: return copy to public pool
                        bookDao.updateAvailableCopies(conn, bookId, 1);
                    }

                    conn.commit();
                } catch (Exception ex) {
                    conn.rollback();
                    throw new LibraryException("Transaction failed during book return: " + ex.getMessage(), 500);
                }
            }

            // Refresh book cache
            bookService.syncCache();

            // Prepare response summary
            Map<String, Object> response = new HashMap<>();
            response.put("issueId", issueId);
            response.put("bookTitle", issue.getBookTitle());
            response.put("memberName", issue.getMemberName());
            response.put("returnDate", today);
            response.put("isOverdue", isOverdue);
            response.put("overdueDays", overdueDays);
            response.put("allocatedToQueue", allocatedReservation != null);
            if (allocatedReservation != null) {
                response.put("allocatedMemberName", allocatedReservation.getMemberName());
                response.put("allocatedMemberEmail", allocatedReservation.getMemberEmail());
                response.put("reservationId", allocatedReservation.getId());
            }

            return response;

        } catch (SQLException e) {
            throw new LibraryException("Database error: " + e.getMessage(), 500);
        }
    }

    public List<IssueRecord> getAllIssues() throws SQLException {
        return issueDao.findAll();
    }

    public List<IssueRecord> getIssuesByMemberId(int memberId) throws SQLException {
        return issueDao.findByMemberId(memberId);
    }
}
