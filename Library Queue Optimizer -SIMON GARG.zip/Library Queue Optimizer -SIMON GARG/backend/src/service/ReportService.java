package service;

import dao.BookDao;
import dao.IssueDao;
import dao.MemberDao;
import dao.ReservationDao;
import exceptions.LibraryException;
import model.*;

import java.sql.SQLException;
import java.util.*;

/**
 * Report and Analytics Service.
 * Implements compulsory sorting using Java Comparator:
 * - Overdue books sorted by overdue days descending
 * - Frequently borrowed books sorted by borrow count descending
 * - Reservations sorted by reservation date and queue position
 */
public class ReportService {
    private final IssueDao issueDao;
    private final BookDao bookDao;
    private final MemberDao memberDao;
    private final ReservationDao reservationDao;

    public ReportService(IssueDao issueDao, BookDao bookDao, MemberDao memberDao, ReservationDao reservationDao) {
        this.issueDao = issueDao;
        this.bookDao = bookDao;
        this.memberDao = memberDao;
        this.reservationDao = reservationDao;
    }

    /**
     * Overdue Books Report:
     * Sorted using Comparator by overdue days descending.
     */
    public List<OverdueReportItem> getOverdueReport() throws SQLException {
        List<OverdueReportItem> items = issueDao.getOverdueRecords();

        // Compulsory Comparator implementation
        Comparator<OverdueReportItem> overdueComparator = new Comparator<OverdueReportItem>() {
            @Override
            public int compare(OverdueReportItem a, OverdueReportItem b) {
                return Long.compare(b.getOverdueDays(), a.getOverdueDays()); // Descending
            }
        };

        items.sort(overdueComparator);
        return items;
    }

    /**
     * Frequently Borrowed / Popular Books Report:
     * Sorted using Comparator by borrowing frequency descending and assigned popularity ranks.
     */
    public List<PopularBookReportItem> getPopularBooksReport() throws SQLException {
        List<Book> books = bookDao.findAll();
        Map<Integer, Integer> borrowCounts = issueDao.getBorrowCounts();

        List<PopularBookReportItem> list = new ArrayList<>();
        for (Book b : books) {
            int count = borrowCounts.getOrDefault(b.getId(), 0);
            list.add(new PopularBookReportItem(
                    b.getId(),
                    b.getIsbn(),
                    b.getTitle(),
                    b.getAuthor(),
                    b.getCategory(),
                    b.getTotalCopies(),
                    b.getAvailableCopies(),
                    count,
                    0
            ));
        }

        // Compulsory Comparator implementation
        Comparator<PopularBookReportItem> popularityComparator = new Comparator<PopularBookReportItem>() {
            @Override
            public int compare(PopularBookReportItem a, PopularBookReportItem b) {
                int cmp = Integer.compare(b.getBorrowCount(), a.getBorrowCount());
                if (cmp != 0) return cmp;
                return a.getTitle().compareToIgnoreCase(b.getTitle());
            }
        };

        list.sort(popularityComparator);

        // Assign ranks
        int rank = 1;
        for (PopularBookReportItem item : list) {
            item.setPopularityRank(rank++);
        }

        return list;
    }

    /**
     * Reservation Report:
     * Sorted using Comparator by reservation date ascending and queue position.
     */
    public List<Reservation> getReservationReport() throws SQLException {
        List<Reservation> list = reservationDao.findAll();

        // Compulsory Comparator implementation
        Comparator<Reservation> reservationComparator = new Comparator<Reservation>() {
            @Override
            public int compare(Reservation a, Reservation b) {
                int statusCmp = a.getStatus().compareTo(b.getStatus());
                if (statusCmp != 0) return statusCmp;
                int posCmp = Integer.compare(a.getQueuePosition(), b.getQueuePosition());
                if (posCmp != 0) return posCmp;
                return a.getReservationDate().compareTo(b.getReservationDate());
            }
        };

        list.sort(reservationComparator);
        return list;
    }

    /**
     * Executive Dashboard Overview Stats.
     */
    public DashboardStats getDashboardStats() throws SQLException {
        List<Member> members = memberDao.findAll();
        List<Book> books = bookDao.findAll();
        List<OverdueReportItem> overdues = issueDao.getOverdueRecords();

        int totalCopies = 0;
        int availableCopies = 0;
        for (Book b : books) {
            totalCopies += b.getTotalCopies();
            availableCopies += b.getAvailableCopies();
        }

        int issuedBooks = issueDao.countActiveIssues();
        int activeReservations = reservationDao.countActiveReservations();
        int overdueCount = overdues.size();

        List<IssueRecord> recentIssues = issueDao.getRecentIssues(5);
        List<IssueRecord> recentReturns = issueDao.getRecentReturns(5);
        List<PopularBookReportItem> popular = getPopularBooksReport();
        if (popular.size() > 5) {
            popular = popular.subList(0, 5);
        }

        return new DashboardStats(
                members.size(),
                books.size(),
                totalCopies,
                availableCopies,
                issuedBooks,
                activeReservations,
                overdueCount,
                recentIssues,
                recentReturns,
                popular
        );
    }
}
